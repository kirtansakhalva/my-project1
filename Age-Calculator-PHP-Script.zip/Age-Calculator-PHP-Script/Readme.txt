How to Run Age Calculator using PHP

1. Download the project zip file

2. Extract the file and copy age_calculator_php folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4. Run the script http://localhost/age_calculator_php